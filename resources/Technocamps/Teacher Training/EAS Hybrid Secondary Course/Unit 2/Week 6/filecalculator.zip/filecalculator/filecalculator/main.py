"""
This module provides the main program for this package.
The function is to load a series of numbers and perform calculations on them.
"""


import seriescalculator
import filehandler


FILE_NAME = "numbers.csv"


def main():
	"""
	This is the main program.

	A series is loaded and its sum, difference, result and remainder are 
	printed.
	"""
	
	number_series = filehandler.load_series(FILE_NAME)

	print(f"The sum of all numbers is {seriescalculator.add_series(
													number_series)}")

	print(f"The difference of all numbers is {seriescalculator.subtract_series(
													number_series)}")

	print(f"The result of all numbers is {seriescalculator.multiply_series(
													number_series)}")

	print(f"The remainder of all numbers is {seriescalculator.divide_series(
													number_series)}")


main()
