"""
This module provides file loading functions.
"""

import os


def open_file(file_name):
	"""
	This opens a file in read mode from the resources folder.

	Args:		
			file_name (String): The file name

	Returns: 
			file: The actual opened file, ready to read
	"""

	current_dir = os.path.dirname(__file__)

	file_path = os.path.join(current_dir, "..", "resources", file_name)

	return open(file_path, "r")


def load_series(file_name):
	"""
	This loads a series (i.e. a single array of numbers) from a file.

	The file type is not specified but it expects the series to be separated
	by newline characters!

	Args:		
			file_name (String): The file name

	Returns: 
			list: The number series
	"""
	
	data_file = open_file(file_name)

	series = []

	# Load each line of the file, strip the new line character,
	# typecast to an integer, then append to the list
	for line in data_file:

		series.append( int( line.strip()))

	data_file.close()

	return series

	

