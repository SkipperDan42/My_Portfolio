"""
This module provides calculator functions.
"""

def add(a, b):
	"""
	This adds two numbers.

	Args:		
			a (int): The first number
			b (int): The second number

	Returns: 
			int: The sum of both numbers
	"""

	return a + b


def subtract(a, b):
	"""
	This subtracts two numbers.

	Args:		
			a (int): The first number
			b (int): The second number

	Returns: 
			int: The difference of both numbers
	"""

	return a - b


def multiply(a, b):
	"""
	This multiplies two numbers.

	Args:		
			a (int): The first number
			b (int): The second number

	Returns: 
			int: The result of both numbers
	"""

	return a * b


def divide(a, b):
	"""
	This divides two numbers.

	Args:		
			a (int): The first number
			b (int): The second number

	Returns: 
			int: The remainder of both numbers
	"""
	try:
		return a / b
	except ZeroDivisionError as e:
		print(f"Error: {e}")
		return 0