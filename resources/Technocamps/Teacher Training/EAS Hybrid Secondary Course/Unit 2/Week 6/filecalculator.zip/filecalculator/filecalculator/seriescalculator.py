"""
This module implements the calculator functions on a series.
"""


import calculator


def add_series(series):
	"""
	This adds all numbers in the series.

	Args:		
			series (list): The series of numbers

	Returns: 
			int: The sum of all numbers
	"""

	total = 0

	for number in series:

		total = calculator.add(total, number)

	return total


def subtract_series(series):
	"""
	This subtracts all numbers in the series.

	Args:		
			series (list): The series of numbers

	Returns: 
			int: The difference of all numbers
	"""

	total = 0

	for number in series:
		
		total = calculator.subtract(total, number)

	return total


def multiply_series(series):
	"""
	This multiplies all numbers in the series.

	Args:		
			series (list): The series of numbers

	Returns: 
			int: The result of all numbers
	"""

	total = 1

	for number in series:
		
		total = calculator.multiply(total, number)

	return total


def divide_series(series):
	"""
	This divides all numbers in the series.

	Args:		
			series (list): The series of numbers

	Returns: 
			float: The remainder of all numbers
	"""

	total = 1

	for number in series:
		
		total = calculator.divide(total, number)

	return total