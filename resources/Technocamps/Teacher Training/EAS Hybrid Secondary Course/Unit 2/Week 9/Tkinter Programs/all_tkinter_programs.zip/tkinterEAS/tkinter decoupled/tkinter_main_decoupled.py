################################################################
# This is the full implementation we were doing in the session #
# But now it is split across multiple files! Yay!              #
# Also the totalSales works here by passing parameters...      #
################################################################

from tkinter_login_decoupled import tk_login

# We kick off our program by calling the login function
tk_login()