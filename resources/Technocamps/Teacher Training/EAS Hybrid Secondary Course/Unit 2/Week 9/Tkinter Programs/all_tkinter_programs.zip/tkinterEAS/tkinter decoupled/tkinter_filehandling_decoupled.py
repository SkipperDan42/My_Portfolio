# This is the load stock function that is currenty hardcoded
# - you can replace this to load from file
def load_stock():
	items = {

			1: {"Name" : "Ben Shaw's D&B",
			  	"Price": 1.20,
			  	"Stock": 20
				},
			2: {"Name" : "Coca Cola",
			  	"Price": 1.50,
			  	"Stock": 100
				},
			3: {"Name" : "Irn Bru",
			  	"Price": 0.99,
			  	"Stock": 32
				},
			4: {"Name" : "R. White's Lemonade",
			  	"Price": 1.20,
			  	"Stock": 57
				}
			}

	return items


def write_stock():
	pass

